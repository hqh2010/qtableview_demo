#ifndef CMAINWINDOW_H
#define CMAINWINDOW_H

#include <QMainWindow>
#include <QStandardItemModel>
#include "CButtonDelegate.h"

QT_BEGIN_NAMESPACE
namespace Ui { class CMainWindow; }
QT_END_NAMESPACE

class CMainWindow : public QMainWindow
{
    Q_OBJECT
public:
    explicit CMainWindow(QWidget *parent = 0);
    ~CMainWindow();

private slots:
    void on_itemClick(int row); //代理按钮被点击所调用的槽函数

private:
    Ui::CMainWindow *ui;
    QStandardItemModel  *m_model;       //tableview中的项目模型
    CButtonDelegate     *m_delegate;    //按钮代理指针
};
#endif // CMAINWINDOW_H
