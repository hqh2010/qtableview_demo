#include "cmainwindow.h"
#include "ui_cmainwindow.h"

#include <QDebug>

CMainWindow::CMainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::CMainWindow)
{
    ui->setupUi(this);

    //new出模型对象，并设置到view上
    m_model = new QStandardItemModel;
    m_model->setHorizontalHeaderLabels(
                QStringList() << "普通列" << "普通列" << "代理列");   //添加列标题

    ui->tableView->setModel(m_model);

    //new出代理对象，并设置到相应列
    m_delegate = new CButtonDelegate;
    connect(m_delegate, &CButtonDelegate::clicked, this, &CMainWindow::on_itemClick);   //连接槽函数
    ui->tableView->setItemDelegateForColumn(2, m_delegate);

    //for循环建立假数据
    for(int index = 0; index != 5; ++index)
    {
        m_model->setItem(index, 0, new QStandardItem(QString("第%1行，第0列").arg(index)));
        m_model->setItem(index, 1, new QStandardItem(QString("第%1行，第1列").arg(index)));
    }
    ui->tableView->setRowHeight(0, 64);
    ui->tableView->setRowHeight(1, 64);
    ui->tableView->setColumnWidth(2,64);
    ui->tableView->setColumnWidth(1,64);
}

CMainWindow::~CMainWindow()
{
    delete m_delegate;
    delete m_model;
    delete ui;
}

void CMainWindow::on_itemClick(int row)
{
    qDebug() << QString("点击了第%1行").arg(row);
}



