#include "CButtonDelegate.h"
#include <QPushButton>
#include <QMouseEvent>

CButtonDelegate::CButtonDelegate(QStyledItemDelegate *parent) : QStyledItemDelegate(parent)
{}

void CButtonDelegate::paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const
{
    Q_UNUSED(index);
    QStyleOptionButton btnStyle;
    //    btnStyle.text = "我;             //设置按钮文本
    btnStyle.rect = option.rect;            //设置按钮区域为当前item的rect
    btnStyle.state = QStyle::State_Enabled; //设置按钮状态
//    F:\qtdemo\demo\img
//    btnStyle.icon = QIcon("/home/uos/Desktop/qtdemo/demo/img/eDevice.png");
    btnStyle.icon = QIcon("F:/qtdemo/demo/img/eDevice.png");
    btnStyle.iconSize = QSize(64,64);
//    QPalette palette1 = QPalette();
//    palette1.setColor(QPalette::Button, Qt::red);
//    btnStyle.palette = palette1;

    QPushButton btn;
    btn.setStyleSheet("background-color:red;");
    btn.style()->drawControl(QStyle::CE_PushButton, &btnStyle, painter,&btn);   //将按钮绘制出来
}

bool CButtonDelegate::editorEvent(QEvent *event, QAbstractItemModel *model, const QStyleOptionViewItem &option, const QModelIndex &index)
{
    Q_UNUSED(model);
    QMouseEvent *mouseEvent = static_cast<QMouseEvent *>(event);
    if(option.rect.contains(mouseEvent->pos()))
    {
        //此次将会发送两次信号（按下触发和释放触发），若只需要一次信号则添加判断即可
        //判断按下：event->type() == QEvent::MouseButtonPress
        //判断释放：event->type() == QEvent::MouseButtonRelease
        emit clicked(index.row());
    }
}
