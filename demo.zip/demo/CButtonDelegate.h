#ifndef CBUTTONDELEGATE_H
#define CBUTTONDELEGATE_H

#include <QObject>
#include <QStyledItemDelegate>

class CButtonDelegate : public QStyledItemDelegate
{
    Q_OBJECT
public:
    explicit CButtonDelegate(QStyledItemDelegate *parent = nullptr);
    //设置按钮样式和文本
    void paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const;

    //相应item的编辑事件
    bool editorEvent(QEvent *event, QAbstractItemModel *model, const QStyleOptionViewItem &option, const QModelIndex &index);

signals:
    void clicked(int row);  //发出点击信号，并传出当前行
};

#endif // CBUTTONDELEGATE_H
